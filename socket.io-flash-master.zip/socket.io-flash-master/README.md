# socket.io-flash

Flash library to facilitate communication between Flash applications and Socket.IO(>= v.0.8) servers.
The library supports the following transports:

- xhr-polling
- websocket (via https://github.com/gimite/web-socket-js)

# How to try the sample

See github repo https://github.com/sinnus/socket.io-flash-demo